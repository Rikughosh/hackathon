<script setup lang="ts">
import { ref } from 'vue'
import Navigation from './components/Navigation.vue'
import Footer from './components/Footer.vue'
import AccessibilityControls from './components/AccessibilityControls.vue'

const fontSize = ref(16)
const highContrast = ref(false)

const updateFontSize = (size: number) => {
  fontSize.value = size
  document.documentElement.style.fontSize = `${size}px`
}

const toggleHighContrast = () => {
  highContrast.value = !highContrast.value
  document.documentElement.classList.toggle('high-contrast')
}
</script>

<template>
  <div :class="{ 'high-contrast': highContrast }">
    <AccessibilityControls
      :font-size="fontSize"
      :high-contrast="highContrast"
      @update-font-size="updateFontSize"
      @toggle-contrast="toggleHighContrast"
    />
    <Navigation />
    <main class="container mx-auto px-4 py-8">
      <router-view></router-view>
    </main>
    <Footer />
  </div>
</template>

<style>
.high-contrast {
  background-color: #000;
  color: #fff;
}

.high-contrast a {
  color: #ffff00;
}

.high-contrast button {
  background-color: #fff;
  color: #000;
}
</style>