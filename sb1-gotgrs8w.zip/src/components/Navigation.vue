<script setup lang="ts">
const menuItems = [
  { name: 'Home', path: '/' },
  { name: 'Learning Hub', path: '/learning' },
  { name: 'Community', path: '/community' },
  { name: 'Resources', path: '/resources' },
]
</script>

<template>
  <nav class="bg-blue-600 text-white p-4" role="navigation">
    <div class="container mx-auto flex justify-between items-center">
      <router-link to="/" class="text-2xl font-bold">Digital India</router-link>
      
      <ul class="flex space-x-6">
        <li v-for="item in menuItems" :key="item.name">
          <router-link
            :to="item.path"
            class="hover:text-blue-200 transition-colors"
            :aria-current="$route.path === item.path ? 'page' : undefined"
          >
            {{ item.name }}
          </router-link>
        </li>
      </ul>
    </div>
  </nav>
</template>