<script setup lang="ts">
import { ref } from 'vue'

const props = defineProps<{
  fontSize: number
  highContrast: boolean
}>()

const emit = defineEmits<{
  (e: 'updateFontSize', size: number): void
  (e: 'toggleContrast'): void
}>()

const showControls = ref(false)
</script>

<template>
  <div 
    class="fixed top-4 right-4 z-50 bg-white shadow-lg rounded-lg p-4"
    role="region"
    aria-label="Accessibility Controls"
  >
    <button
      @click="showControls = !showControls"
      class="accessibility-button"
      aria-expanded="showControls"
    >
      <span class="sr-only">Toggle Accessibility Controls</span>
      <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
      </svg>
    </button>

    <div v-if="showControls" class="mt-4">
      <div class="mb-4">
        <label for="fontSize" class="block mb-2">Font Size</label>
        <input
          type="range"
          id="fontSize"
          :value="fontSize"
          @input="emit('updateFontSize', Number($event.target.value))"
          min="12"
          max="24"
          step="1"
          class="w-full"
        />
      </div>

      <div class="mb-4">
        <button
          @click="emit('toggleContrast')"
          class="w-full p-2 border rounded"
          :aria-pressed="highContrast"
        >
          Toggle High Contrast
        </button>
      </div>
    </div>
  </div>
</template>