import { createRouter, createWebHistory } from 'vue-router'
import Home from '../views/Home.vue'
import LearningHub from '../views/LearningHub.vue'
import Community from '../views/Community.vue'
import Resources from '../views/Resources.vue'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/',
      name: 'Home',
      component: Home,
    },
    {
      path: '/learning',
      name: 'Learning Hub',
      component: LearningHub,
    },
    {
      path: '/community',
      name: 'Community',
      component: Community,
    },
    {
      path: '/resources',
      name: 'Resources',
      component: Resources,
    },
  ],
})

export default router