<script setup lang="ts">
import { ref } from 'vue'

const features = [
  {
    title: 'Accessible Learning',
    description: 'Educational content designed for everyone, with screen reader support and adaptive interfaces.',
    icon: '🎓'
  },
  {
    title: 'Skill Development',
    description: 'Learn in-demand skills through our inclusive training programs.',
    icon: '💡'
  },
  {
    title: 'Community Support',
    description: 'Connect with mentors and peers in our supportive community.',
    icon: '🤝'
  }
]
</script>

<template>
  <div class="min-h-screen">
    <section class="hero py-20 text-center" role="banner">
      <h1 class="text-4xl font-bold mb-6">Welcome to Digital India</h1>
      <p class="text-xl mb-8">Empowering everyone through accessible digital education</p>
    </section>

    <section 
      class="features py-16"
      role="region"
      aria-label="Platform Features"
    >
      <div class="grid md:grid-cols-3 gap-8">
        <div
          v-for="feature in features"
          :key="feature.title"
          class="feature-card p-6 rounded-lg shadow-lg"
        >
          <span class="text-4xl mb-4 block">{{ feature.icon }}</span>
          <h2 class="text-2xl font-semibold mb-4">{{ feature.title }}</h2>
          <p>{{ feature.description }}</p>
        </div>
      </div>
    </section>
  </div>
</template>